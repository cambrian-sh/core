--
-- PostgreSQL database dump
--

\restrict PFffViDwiPw1f6njy0Yyibl6Oqu1kBGtcjq5pJcQc7Ae1jfyNqu5aEQzyor2lqz

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg12+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.document_edges DROP CONSTRAINT IF EXISTS document_edges_target_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_edges DROP CONSTRAINT IF EXISTS document_edges_source_id_fkey;
DROP INDEX IF EXISTS public.idx_operator_audit_ts;
DROP INDEX IF EXISTS public.idx_operator_audit_target;
DROP INDEX IF EXISTS public.idx_operator_audit_actor;
DROP INDEX IF EXISTS public.idx_doc_metadata;
DROP INDEX IF EXISTS public.idx_doc_embedding_cosine;
DROP INDEX IF EXISTS public.idx_doc_edges_target;
DROP INDEX IF EXISTS public.idx_doc_edges_source;
ALTER TABLE IF EXISTS ONLY public.operator_audit DROP CONSTRAINT IF EXISTS operator_audit_pkey;
ALTER TABLE IF EXISTS ONLY public.operator_audit DROP CONSTRAINT IF EXISTS operator_audit_command_id_key;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.document_edges DROP CONSTRAINT IF EXISTS document_edges_pkey;
ALTER TABLE IF EXISTS ONLY public.agent_scopes DROP CONSTRAINT IF EXISTS agent_scopes_pkey;
DROP TABLE IF EXISTS public.operator_audit;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.document_edges;
DROP TABLE IF EXISTS public.agent_scopes;
DROP FUNCTION IF EXISTS public.update_activation_strength(doc_id text, delta double precision);
DROP FUNCTION IF EXISTS public.apply_ebbinghaus_decay(min_gc_age_days integer);
DROP EXTENSION IF EXISTS vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: apply_ebbinghaus_decay(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.apply_ebbinghaus_decay(min_gc_age_days integer DEFAULT 30) RETURNS void
    LANGUAGE plpgsql
    AS $$
			DECLARE
				lambda  CONSTANT DOUBLE PRECISION := 0.001;
				epsilon CONSTANT DOUBLE PRECISION := 0.02;
				eta     CONSTANT DOUBLE PRECISION := 0.005;
			BEGIN
				UPDATE documents
				SET activation_strength = GREATEST(0.0, LEAST(1.0,
					(activation_strength + eta * access_count) * EXP(-1 * lambda) * (1 - epsilon)
				));

				DELETE FROM documents
				WHERE activation_strength <= 0.05
				  AND access_count = 0
				  AND created_at < NOW() - (min_gc_age_days || ' days')::INTERVAL;
			END;
			$$;


--
-- Name: update_activation_strength(text, double precision); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_activation_strength(doc_id text, delta double precision) RETURNS void
    LANGUAGE plpgsql
    AS $$
			BEGIN
				UPDATE documents
				SET activation_strength = LEAST(0.8, GREATEST(0.0, activation_strength + delta))
				WHERE id = doc_id;
			END;
			$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_scopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_scopes (
    agent_id text NOT NULL,
    profile jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    write_tags jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: document_edges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_edges (
    source_id text NOT NULL,
    target_id text NOT NULL,
    edge_type character varying(50) NOT NULL,
    weight real DEFAULT 0.5 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id text NOT NULL,
    text text NOT NULL,
    embedding public.vector(768),
    metadata jsonb,
    access_count integer DEFAULT 0,
    activation_strength double precision DEFAULT 0.1 NOT NULL,
    scoring_prompt_version character varying(8) DEFAULT ''::character varying NOT NULL,
    last_accessed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    document_type character varying(32) DEFAULT 'memory'::character varying NOT NULL,
    version integer DEFAULT 1,
    summary text DEFAULT ''::text NOT NULL
);


--
-- Name: operator_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operator_audit (
    id text NOT NULL,
    command_id text NOT NULL,
    ts timestamp with time zone NOT NULL,
    actor text NOT NULL,
    role text NOT NULL,
    action_type text NOT NULL,
    target_type text NOT NULL,
    target_id text NOT NULL,
    before_json text NOT NULL,
    after_json text NOT NULL,
    reason text NOT NULL,
    result text NOT NULL
);


--
-- Data for Name: agent_scopes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_scopes (agent_id, profile, updated_at, write_tags) FROM stdin;
\.


--
-- Data for Name: document_edges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_edges (source_id, target_id, edge_type, weight, created_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, text, embedding, metadata, access_count, activation_strength, scoring_prompt_version, last_accessed_at, created_at, document_type, version, summary) FROM stdin;
profile:analyst_agent:d29a9864bbb8563b3ca6bbab175a64969f2308120b3a43f27f47386b0c223b80	{"agent_id":"analyst_agent","source_hash":"d29a9864bbb8563b3ca6bbab175a64969f2308120b3a43f27f47386b0c223b80","model_metrics":{}}	\N	{"agent_id": "analyst_agent", "source_hash": "d29a9864bbb8563b3ca6bbab175a64969f2308120b3a43f27f47386b0c223b80"}	0	0		0001-01-01 00:00:00	2026-07-01 16:01:04.283114	agent_profile	44	
profile:calculator_agent:4ec337a3f25305702ab27c7c91f5aca3e331ae3f6553f7f1575297c8c84c338c	{"agent_id":"calculator_agent","source_hash":"4ec337a3f25305702ab27c7c91f5aca3e331ae3f6553f7f1575297c8c84c338c","model_metrics":{}}	\N	{"agent_id": "calculator_agent", "source_hash": "4ec337a3f25305702ab27c7c91f5aca3e331ae3f6553f7f1575297c8c84c338c"}	0	0		0001-01-01 00:00:00	2026-07-01 16:01:04.288204	agent_profile	44	
profile:code_executor_agent:699cf41d343229e8aa547ce2bcfcf7e74d63451f3b64fd9a8be4ccbaeebf2b52	{"agent_id":"code_executor_agent","source_hash":"699cf41d343229e8aa547ce2bcfcf7e74d63451f3b64fd9a8be4ccbaeebf2b52","model_metrics":{}}	\N	{"agent_id": "code_executor_agent", "source_hash": "699cf41d343229e8aa547ce2bcfcf7e74d63451f3b64fd9a8be4ccbaeebf2b52"}	0	0		0001-01-01 00:00:00	2026-07-01 16:01:04.29208	agent_profile	44	
profile:code_generator_agent:748ada0146e6f923dcd4d95bea0da87a48bb2b584510677e159c07a291b1d89f	{"agent_id":"code_generator_agent","source_hash":"748ada0146e6f923dcd4d95bea0da87a48bb2b584510677e159c07a291b1d89f","model_metrics":{}}	\N	{"agent_id": "code_generator_agent", "source_hash": "748ada0146e6f923dcd4d95bea0da87a48bb2b584510677e159c07a291b1d89f"}	0	0		0001-01-01 00:00:00	2026-07-01 16:01:04.296146	agent_profile	44	
profile:research_agent:a19f1487c794ead7b0160d616e913c3d88203e0e50e3a211f742223798de082d	{"agent_id":"research_agent","source_hash":"a19f1487c794ead7b0160d616e913c3d88203e0e50e3a211f742223798de082d","model_metrics":{}}	\N	{"agent_id": "research_agent", "source_hash": "a19f1487c794ead7b0160d616e913c3d88203e0e50e3a211f742223798de082d"}	0	0		0001-01-01 00:00:00	2026-07-01 16:01:04.300072	agent_profile	44	
profile:summariser_agent:df11049b7a1b8b9067a081347038af1a0ac8989881c8c2f247e2624c6df44966	{"agent_id":"summariser_agent","source_hash":"df11049b7a1b8b9067a081347038af1a0ac8989881c8c2f247e2624c6df44966","model_metrics":{}}	\N	{"agent_id": "summariser_agent", "source_hash": "df11049b7a1b8b9067a081347038af1a0ac8989881c8c2f247e2624c6df44966"}	0	0		0001-01-01 00:00:00	2026-07-01 16:01:04.309472	agent_profile	44	
profile:terminal_agent:74058aac149cd9f3e156ff0f1671467bf1e67af7c2af8640939aaa310d702c68	{"agent_id":"terminal_agent","source_hash":"74058aac149cd9f3e156ff0f1671467bf1e67af7c2af8640939aaa310d702c68","model_metrics":{}}	\N	{"agent_id": "terminal_agent", "source_hash": "74058aac149cd9f3e156ff0f1671467bf1e67af7c2af8640939aaa310d702c68"}	0	0		0001-01-01 00:00:00	2026-07-01 16:01:04.313041	agent_profile	44	
\.


--
-- Data for Name: operator_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operator_audit (id, command_id, ts, actor, role, action_type, target_type, target_id, before_json, after_json, reason, result) FROM stdin;
\.


--
-- Name: agent_scopes agent_scopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_scopes
    ADD CONSTRAINT agent_scopes_pkey PRIMARY KEY (agent_id);


--
-- Name: document_edges document_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_edges
    ADD CONSTRAINT document_edges_pkey PRIMARY KEY (source_id, target_id, edge_type);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: operator_audit operator_audit_command_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operator_audit
    ADD CONSTRAINT operator_audit_command_id_key UNIQUE (command_id);


--
-- Name: operator_audit operator_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operator_audit
    ADD CONSTRAINT operator_audit_pkey PRIMARY KEY (id);


--
-- Name: idx_doc_edges_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_edges_source ON public.document_edges USING btree (source_id);


--
-- Name: idx_doc_edges_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_edges_target ON public.document_edges USING btree (target_id);


--
-- Name: idx_doc_embedding_cosine; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_embedding_cosine ON public.documents USING hnsw (embedding public.vector_cosine_ops) WITH (m='24', ef_construction='100');


--
-- Name: idx_doc_metadata; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_doc_metadata ON public.documents USING gin (metadata jsonb_path_ops);


--
-- Name: idx_operator_audit_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operator_audit_actor ON public.operator_audit USING btree (actor);


--
-- Name: idx_operator_audit_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operator_audit_target ON public.operator_audit USING btree (target_type, target_id);


--
-- Name: idx_operator_audit_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operator_audit_ts ON public.operator_audit USING btree (ts DESC);


--
-- Name: document_edges document_edges_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_edges
    ADD CONSTRAINT document_edges_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_edges document_edges_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_edges
    ADD CONSTRAINT document_edges_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict PFffViDwiPw1f6njy0Yyibl6Oqu1kBGtcjq5pJcQc7Ae1jfyNqu5aEQzyor2lqz

